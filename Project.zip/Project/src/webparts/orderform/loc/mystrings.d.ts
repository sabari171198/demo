declare interface IOrderformWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'OrderformWebPartStrings' {
  const strings: IOrderformWebPartStrings;
  export = strings;
}
