/* tslint:disable */
require("./Orderform.module.css");
const styles = {
  orderform: 'orderform_5c43cf86',
  header: 'header_5c43cf86',
  footer: 'footer_5c43cf86',
  container: 'container_5c43cf86',
  row: 'row_5c43cf86',
  column: 'column_5c43cf86',
  'ms-Grid': 'ms-Grid_5c43cf86',
  title: 'title_5c43cf86',
  subTitle: 'subTitle_5c43cf86',
  description: 'description_5c43cf86',
  button: 'button_5c43cf86',
  label: 'label_5c43cf86'
};

export default styles;
/* tslint:enable */