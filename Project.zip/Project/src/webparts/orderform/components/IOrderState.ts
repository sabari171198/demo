import { Dropdown, DropdownMenuItemType, IDropdownStyles, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
export interface IOrderState{
    orderItems: IDropdownOption[];
    custItems: IDropdownOption[];
    prodItems: IDropdownOption[];
    customerId:string;
    productId:string;
    productType: string;
    date: Date;
    unitPrice: string;
    numberOfUnits: string;
    saleValue: string;
    hideOrderId: Boolean;
}
