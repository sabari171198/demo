import * as React from 'react';          //importing all react components
import styles from './Order.module.scss';         //importing all styles from other scss(Syntactically awesome style sheet) file
import { IOrderProps } from './IOrderProps';         //importing IorderfromProps function from Props.ts file
 
import { IOrderState } from './IOrderState';// importing all the available states from IorderForm1state.ts
import {DatePicker, MarqueeSelection, TextField } from 'office-ui-fabric-react'; // importing textfield from office ui
import { IStackTokens, Stack } from 'office-ui-fabric-react/lib/Stack';//import stack and stacktokens to manage the dropdown properties
import { Dropdown, IDropdownStyles, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';// import dropdown from office ui
import { DateTimePicker, DateConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';//import date picker from office ui
import { PrimaryButton } from 'office-ui-fabric-react';//import primary button from office ui
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/views";
import "@pnp/sp/items";
 
//Declaration of dropdown array for required fields
var customerItems: IDropdownOption[]=[];
var productItems: IDropdownOption[]=[];
var orderItems: IDropdownOption[]=[];
 
//Declaration of required variables
var productName = '';
var customerName=''; 
var orderId;
 
//Class extending all the react components
 
export default class Order extends React.Component<IOrderProps, IOrderState> {
 
  //Passing props and states to the constructor
  public constructor(props: IOrderProps, state: IOrderState){ 
    super(props); 
    this.state = { 
      //Assigned States from IOrderform1State.tsx
      orderItems: [],
      custItems: [],
      customerId:'',
      prodItems: [],
      productType: '',
      date: new Date(),
      unitPrice: '',
      productId:'',
      numberOfUnits: '',
      saleValue: '',
      hideOrderId :false
    }; 
   //Binding Functions
   // bind is used to send data as an arguments to the function  of class based components
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeCust = this.handleChangeCust.bind(this);
    this.autoPopulate = this.autoPopulate.bind(this);
    this.handleUnitChange = this.handleUnitChange.bind(this);
    this.addToOrderList = this.addToOrderList.bind(this);
    this.handleChangeOrd = this.handleChangeOrd.bind(this);
    this.editOrderList = this.editOrderList.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.resetOrderList = this.resetOrderList.bind(this);
  }
 
  private handleChange(event): void {
    productName = event.key;
    this.setState({ numberOfUnits: '' }),
    this.setState({ saleValue: '' }),
    this.autoPopulate();
  }
 
  
  //Getting customer id when customer name is selected
  async handleChangeCust(event): Promise<void> {
    try {
      customerName = event.key;
      let items = await sp.web.lists.getByTitle("Customers").items.getPaged();//Getting the list items from the customers list
      for (let i = 0; i < items.results.length; i++) {
        if (items.results[i].CustomerName == customerName) {
          this.setState({ customerId: items.results[i].CustomerID })
         
        }
      }
    } catch (error) {
      console.error(error);
    }
 
  }
 
//getting order details when OrderID is selected
async handleChangeOrd(event): Promise<void> {
  try {
    orderId = event.key;
    let items = await sp.web.lists.getByTitle("Orders").items.getPaged();//Getting the list items from the Orders list
    for (let i = 0; i < items.results.length; i++) {
 
      if (items.results[i].OrderID == orderId) {
        this.setState({ productId: items.results[i].ProductID })
        this.setState({ customerId: items.results[i].CustomerID })
        this.setState({ unitPrice: items.results[i].UnitPrice });
        this.setState({ numberOfUnits: items.results[i].UnitsSold });
        this.setState({ unitPrice: items.results[i].UnitPrice });
        this.setState({ saleValue: items.results[i].SalesValue });
      }
    }
    let customeritems = await sp.web.lists.getByTitle("Customers").items.getPaged();
    for (let i = 0; i < customeritems.results.length; i++) {
      debugger
      if (customeritems.results[i].CustomerID == this.state.customerId) {
        customerName = customeritems.results[i].CustomerName;
      }
    }
    let productitems = await sp.web.lists.getByTitle("Products").items.getPaged();
    for (let i = 0; i < productitems.results.length; i++) {
      if (productitems.results[i].ProductID == this.state.productId) {
        productName = productitems.results[i].ProductName;
        this.setState({ productType: productitems.results[i].ProductType });
        this.setState({ date: new Date(productitems.results[i].ProductExpiryDate) });
      }
    }
  } catch (error) {
    console.error(error);
  }
 
}
 
  //Autopopulating fields  when product name is selected
  async autoPopulate(): Promise<void> {
    try {
      let items = await sp.web.lists.getByTitle("Products").items.getPaged();
 
      for (let i = 0; i < items.results.length; i++) {
        if (items.results[i].ProductName == productName) {
          this.setState({ productId: items.results[i].ProductID })
          this.setState({ productType: items.results[i].ProductType });
          this.setState({ unitPrice: items.results[i].ProductUnitPrice });
          this.setState({ date: new Date(items.results[i].ProductExpiryDate) });
        }
      }
    } catch (error) {
      console.error(error);
    }
  }
 
   //Calculating Sale Value
   handleUnitChange = (event) => {
    this.setState({ numberOfUnits: event.target.value.toString() });
    var units: number = parseInt(event.target.value);
    var unitPrice: number = parseInt(this.state.unitPrice);
    var calculate = units * unitPrice;
    this.setState({ saleValue: calculate.toString() });
    return event;
  }
 
  //Adding order to orders list
  async addToOrderList(event): Promise<void> {
    try {
      debugger
      var unitvalid = this.state.numberOfUnits;
      if (customerName == "" || productName == "") {
        alert("Please Select Customer Name From Dropdown" + "\n" + "Please Select Product Name From Dropdown");
      }
      else if (this.state.numberOfUnits == "" || this.state.numberOfUnits <= "0") {
        alert("Please Enter Number Of Units or You have entered zero units");
      }
      else if (Number(unitvalid) !== parseInt(unitvalid) && Number(unitvalid) % 1 !== 0) {
        alert("Please enter No. of Units as integer value")
      }
      else {
        let item = await sp.web.lists.getByTitle("Orders").items.add({
          CustomerID: this.state.customerId,
          ProductID: this.state.productId,
          UnitsSold: this.state.numberOfUnits,
          UnitPrice: this.state.unitPrice,
          SalesValue: this.state.saleValue,
          Title: "title"
        });
        alert("Order is added successfully in the list.");
        this.resetOrderList();
      }
    } catch (error) {
      console.error(error);
    }
  }
 
    // //Editing orders
 
    async editOrderList(event): Promise<void> {
      
      try {
        this.setState({ hideOrderId: true })
        var unitvalid = this.state.numberOfUnits;
 
        if (orderId == undefined) 
        {
          alert("Select an order ID for editing"); 
        }
        else if (this.state.numberOfUnits == "" && this.state.customerId =="") 
        {
          this.setState({ hideOrderId: true })
        }
        else{
          if (this.state.numberOfUnits == "" || this.state.numberOfUnits == "0") {
            alert("Please Enter Valid Number Of Units or You have entered zero units");
          }
          else if (Number(unitvalid) !== parseInt(unitvalid) && Number(unitvalid) % 1 !== 0) {
            alert("Please enter No. of Units as integer value")
          }
          else{
               let list = sp.web.lists.getByTitle("Orders");
               orderId = orderId.replace('ORD-','');
               const i = await list.items.getById(orderId).update({
               CustomerID: this.state.customerId,
               ProductID: this.state.productId,
               UnitsSold: this.state.numberOfUnits,
               UnitPrice: this.state.unitPrice,
               SalesValue: this.state.saleValue,
               Title: "title"
          
             });
            alert("ORD-"+orderId+" is updated successfully in the list.");
            this.resetOrderList();
    
        }}}
        catch (error) {
        console.error(error);
      }
    }
 
        //Deleting order
        async deleteItem(event):Promise<void>
        {
        try {
        this.setState({hideOrderId:true})
 
        if (orderId == undefined) 
        {
        alert("Select an order ID to delete"); 
        }
        let list = sp.web.lists.getByTitle("Orders");
        orderId = orderId.replace('ORD-','');
        await list.items.getById(orderId).delete();
        alert("[Success : Item Deleted] "+"\n"+ "ORD-"+orderId+ " Has Been Deleted \n");
        this.resetOrderList();
        } catch (error) {
        console.log(error);
        }
        }
  
  
      //Resetting fields
      private resetOrderList(): void {
        customerName = '';
        productName = '';
        orderId = undefined;
 
        this.setState({
          date: new Date(),
          productType: '',
          unitPrice: '',
          numberOfUnits: '',
          saleValue: ''
        })
      }
 
// ComponentDidMount function is called after render function
  public async componentDidMount(): Promise<void>
  {
    // get all the items from a sharepoint list
    var reacthandler=this;
    sp.web.lists.getByTitle("Customers").items.select('CustomerName').get().then(function(data){
      for(var k in data){
        customerItems.push({key:data[k].CustomerName, text:data[k].CustomerName});
      }
      reacthandler.setState({custItems:customerItems});
      console.log(customerItems);
      return customerItems;
    });
 
    sp.web.lists.getByTitle("Products").items.select('ProductName').get().then(function(data){
      for(var k in data){
        productItems.push({key:data[k].ProductName, text:data[k].ProductName});
      }
      reacthandler.setState({prodItems:productItems});
      console.log(productItems);
      return productItems;
    });
 
    sp.web.lists.getByTitle("Orders").items.select('OrderID').get().then(function (data) {
      for (var k in data) {
        orderItems.push({ key: data[k].OrderID, text: data[k].OrderID });
      }
      reacthandler.setState({ orderItems: orderItems });
      console.log(orderItems);
      return orderItems;
    });
  }
 
  public render(): React.ReactElement<IOrderProps> {
   
 
    const dropdownStyles: Partial<IDropdownStyles> = {
     dropdown: { width: 452 }
    };
  
    const stackTokens: IStackTokens = { childrenGap: 12 };
  
    
    // let message="message:"+this.state.customerId;
      return (
        <div className={styles.order }>
        <div className={styles.container }>
          <div>
            <div className={styles.header}>
                <header>
                <img src= {require("./car2.jpg")} alt="logo" width="75" height="50" />
                <h1>Orders</h1>
                <div className={styles.scroll}><h2>Place your orders here!!!</h2></div>
             </header></div>
             <div className={ styles.row }>
              <div className={ styles.column }>
              
                
              <Stack tokens={stackTokens}>
                    <Dropdown 
                      placeholder="Select Customer Name" 
                      label="Customer Name" 
                      selectedKey={customerName}
                      options={this.state.custItems} 
                      styles={dropdownStyles}
                      onChanged={this.handleChangeCust}
                      />
              </Stack>
 
              <Stack tokens={stackTokens}>
                    <Dropdown 
                      placeholder="Select Product Name" 
                      label="Product Name" 
                      selectedKey={productName}
                      options={this.state.prodItems} 
                      styles={dropdownStyles} 
                      onChanged={this.handleChange}
                      />
              </Stack>
              
             <TextField required={true}
                    placeholder="Product Type will Be Entered Automatically"
                    label="Product Type"
                    value ={this.state.productType}
                    onChange={event => {
                      this.setState({ productType: this.state.productType });
                    }}
                    /><br />
                    <DatePicker label="Product Expiry Date"
                  placeholder=""
                  //dateConvention={DateConvention.Date}
                  value={this.state.date}
                  />
                  <TextField required={true}
                    placeholder="Product Unit Price" 
                    label="Product Unit Price"
                    type="number"
                    value ={this.state.unitPrice}
                    onChange={e=>{this.setState({unitPrice: this.state.unitPrice})}}
                    />
              <TextField required={true}
                    placeholder="Enter Number Of Units "
                    label="Number of units"
                    type="number"
                    value ={this.state.numberOfUnits}
                    onChange={this.handleUnitChange}
                    //onChange={e=>{this.setState({ numberOfUnits: 'e' })}}
                    />
                    <div className="HeadText">
              <TextField required={true}
                    placeholder="Total Sale Value"
                    label="Sale Value"
                    type="number"
                    value ={this.state.saleValue}
                    onChange={e=>{this.setState({saleValue: this.state.saleValue})}}
                    />
                                          <Stack tokens={stackTokens}>
                        {
                          this.state.hideOrderId ?
                            <Dropdown required={true}
                              placeholder="Select an Order ID to Edit or Delete"
                              label="Order ID"
                              selectedKey={orderId}
                              options={this.state.orderItems}
                              styles={dropdownStyles}
                              onChanged={this.handleChangeOrd} />
                            : null
                        }
              </Stack><br></br>
              <br></br>
              {/* <button type="Button" onClick={this.calculatePrice} className={styles.buttonCalculate}>Calculate</button> */}
              </div>
                    </div>
                    <div className={ styles.column }>
                <hr/>
                
                <PrimaryButton onClick={this.addToOrderList} >ADD</PrimaryButton>&nbsp;&nbsp;
                <PrimaryButton onClick={this.editOrderList} >EDIT</PrimaryButton>&nbsp;&nbsp;
                <PrimaryButton onClick={this.deleteItem} >DELETE</PrimaryButton>&nbsp;&nbsp;
                <PrimaryButton onClick={this.resetOrderList}>RESET</PrimaryButton>&nbsp;&nbsp;
                <hr/>
                
                
  
              </div> 
          </div>
          <div className={styles.footer}>
            <footer>
              <section>
                <h2 >Copyright &copy; Project belongs to Sabari from CDB21IN005, 2021</h2>
              </section>
            </footer>
          </div>
        </div>
      </div>
      </div>
    );
  }
}
