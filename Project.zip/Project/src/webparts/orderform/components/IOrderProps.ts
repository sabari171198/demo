export interface IOrderProps {
  description: string;
}
