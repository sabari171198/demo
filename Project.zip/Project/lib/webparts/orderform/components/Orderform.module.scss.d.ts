declare const styles: {
    orderform: string;
    header: string;
    footer: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
};
export default styles;
//# sourceMappingURL=Orderform.module.scss.d.ts.map