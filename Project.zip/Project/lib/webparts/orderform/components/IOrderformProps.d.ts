export interface IOrderformProps {
    description: string;
}
//# sourceMappingURL=IOrderformProps.d.ts.map