import * as React from 'react';
import { IOrderformProps } from './IOrderformProps';
import { IOrderformState } from './IOrderformState';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/views";
import "@pnp/sp/items";
export default class Orderform extends React.Component<IOrderformProps, IOrderformState> {
    constructor(props: IOrderformProps, state: IOrderformState);
    private handleChange;
    handleChangeCust(event: any): Promise<void>;
    handleChangeOrd(event: any): Promise<void>;
    autoPopulate(): Promise<void>;
    handleUpdateSaleValue: (event: any) => any;
    addToOrderList(event: any): Promise<void>;
    editOrderList(event: any): Promise<void>;
    private resetOrderList;
    deleteItem(event: any): Promise<void>;
    componentDidMount(): Promise<void>;
    render(): React.ReactElement<IOrderformProps>;
}
//# sourceMappingURL=Orderform.d.ts.map